$(document).ready(function() {

$('.dropdown-item').click(function() {
     
    if($(this).attr('id')=="en"){
         
$(location).attr('href', 'en/index.html');
    }
    
    if($(this).attr('id')=="tr"){
         
        $(location).attr('href', 'index.html');
            }
  });
});
