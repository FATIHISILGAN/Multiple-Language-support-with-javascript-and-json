$(document).ready(function() {
    if ($('[data-toggle="tooltip"]').length > 0) {
        $('[data-toggle="tooltip"]').tooltip();
    }
    var selectedProcess = 1;
    var list1 = $(".CoinList1");
    var list2 = $(".CoinList2");
    var list3 = $(".CoinList3");
    var list4 = $(".CoinList4");
    var selectedDepositCurrency = "BTC"
    var selectedWithdrawCurrency = "USDT"
    var depositCurrency;
    var withdrawCurrency;
    var depositAmount = 1;
    var interval;
    var allAssets = [];
    var quoteDetail;
    var quoteTimeout = null;
    if ($("i.loading-quote").length > 0) {
        $("i.loading-quote").hide();
    }
    if (localStorage.getItem("depositAmount") && localStorage.getItem("selectedProcess") && localStorage.getItem("withdrawCurrency") && localStorage.getItem("depositCurrency")) {
        depositCurrency = JSON.parse(localStorage.getItem("depositCurrency"))
        withdrawCurrency = JSON.parse(localStorage.getItem("withdrawCurrency"))
        selectedProcess = localStorage.getItem("selectedProcess")
        depositAmount = localStorage.getItem("depositAmount");
        selectedDepositCurrency = depositCurrency.Symbol;
        selectedWithdrawCurrency = withdrawCurrency.Symbol;
        if (depositCurrency.DisplayName.includes("(")) {
            var p = depositCurrency.DisplayName.substring(0, depositCurrency.DisplayName.lastIndexOf("("));
        } else {
            var p = depositCurrency.DisplayName
        }
        if (withdrawCurrency.DisplayName.includes("(")) {
            var p2 = withdrawCurrency.DisplayName.substring(0, withdrawCurrency.DisplayName.lastIndexOf("("));
        } else {
            var p2 = withdrawCurrency.DisplayName;
        }
        list2.find("a").html(withdrawCurrency.DisplayName.substring(withdrawCurrency.DisplayName.lastIndexOf("("), withdrawCurrency.DisplayName.lastIndexOf(")") + 1));
        list2.find(".inner").find("span").attr("data-symbol", withdrawCurrency.Symbol);
        list2.find(".inner").find(".icon").attr("src", "assets/images/icons/" + withdrawCurrency.Symbol + ".svg");
        list2.find(".inner").find("span").html(p2);
        list1.find(".inner").find("span").attr("data-symbol", depositCurrency.Symbol);
        list1.find(".inner").find(".icon").attr("src", "assets/images/icons/" + depositCurrency.Symbol + ".svg");
        list1.find(".inner").find("span").html(p);
        list1.find("a").html(depositCurrency.DisplayName.substring(depositCurrency.DisplayName.lastIndexOf("("), depositCurrency.DisplayName.lastIndexOf(")") + 1));
        $("#depositAmount").val(depositAmount);
    }
    Inputmask('decimal', {
        autoUnmask: true,
        digits: 8,
        groupSeparator: ".",
        decimalSeparator: ",",
        autoGroup: true,
        rightAlign: false
    }).mask("#withdrawAmount")
    Inputmask('decimal', {
        autoUnmask: true,
        digits: 8,
        groupSeparator: ".",
        decimalSeparator: ",",
        autoGroup: true,
        rightAlign: false
    }).mask("#depositAmount")
    Inputmask('decimal', {
        autoUnmask: true,
        digits: 8,
        groupSeparator: ".",
        decimalSeparator: ",",
        autoGroup: true,
        rightAlign: false
    }).mask("#depositAmountCredit");
    // $('#depositAmount').mask("#.##0,00#####", {reverse: true});
    clearInterval(interval);
    $("#homeTab").find("span").click(function() {
        $("#homeTab").find("span").removeClass("active");
        // $(".tab").addClass("active"); // instead of this do the below 
        $(this).addClass("active");
        selectedProcess = $(this).data("process");
        if (selectedProcess === 2) {
            $("#creditTab").hide()
            $("#islemTabi").hide()
            $("#takipTabi").show()
        } else if (selectedProcess === 1) {
            $("#creditTab").hide()
            $("#islemTabi").show()
            $("#takipTabi").hide()
        } else {
            $("#islemTabi").hide()
            $("#creditTab").show()
            $("#takipTabi").hide()
        }
    });
    list1.find(".inner").click(x => {
        list1.find(".menu").toggle();
        if (list1.find(".menu input:first").length > 0) {
        	list1.find(".menu input:first").val('').trigger("input").focus();
        }
        $(".overlay").addClass("show");
    })
    list2.find(".inner").click(x => {
        list2.find(".menu").toggle();
        if (list2.find(".menu input:first").length > 0) {
        	list2.find(".menu input:first").val('').trigger("input").focus();
        }
        $(".overlay").addClass("show");
    })
    list3.find(".inner").click(x => {
        list3.find(".menu").toggle();
        if (list3.find(".menu input:first").length > 0) {
        	list3.find(".menu input:first").val('').trigger("input").focus();
        }
        $(".overlay").addClass("show");
    })
    list4.find(".inner").click(x => {
        list4.find(".menu").toggle();
        if (list4.find(".menu input:first").length > 0) {
        	list4.find(".menu input:first").val('').trigger("input").focus();
        }
        $(".overlay").addClass("show");
    })
    $(".overlay").click(x => {
        $(".overlay").removeClass("show");
        list2.find(".menu").hide();
        list1.find(".menu").hide();
        list3.find(".menu").hide();
        list4.find(".menu").hide();
    })
    $("#trackCodeSearchButton").click(x => {
        if ($("#trackCode").val().length === 6) {
            $('#trackCodeSearchButton').html('<i class="fas fa-spinner fa-pulse"></i>');
            fetch(`https://ctyvahls-dev.outsystemsenterprise.com/CointralOnline_Services/rest/Swap/GetSwapStatus?TrackCode=${$("#trackCode").val()}`).then(x => {
                return x.status
            }).then(x => {
                $('#trackCodeSearchButton').html($('#trackCodeSearchButton').data('original'));
                if (x === 400) {
                    var html = `Lütfen geçerli takip kodunu giriniz.`
                    $("#takipTabi").find(".error").show();
                    $("#takipTabi").find(".error").html(html)
                } else {
                    localStorage.setItem("trackCode", $("#trackCode").val())
                    selectedProcess = 2;
                    localStorage.setItem("selectedProcess", selectedProcess)
                    window.location.href = "order.html";
                }
            });
        } else {
            var html = `Lütfen geçerli takip kodunu giriniz.`
            $("#takipTabi").find(".error").show();
            $("#takipTabi").find(".error").html(html)
        }
    })
    var btc, eth, ltc, xrp, bnb;
    fetch("https://api.binance.com/api/v3/ticker/24hr").then(x => {
        return x.json()
    }).then(x => {
        btc = x.filter(x => {
            return x.symbol === "BTCUSDT"
        })[0]
        eth = x.filter(x => {
            return x.symbol === "ETHUSDT"
        })[0]
        ltc = x.filter(x => {
            return x.symbol === "LTCUSDT"
        })[0]
        xrp = x.filter(x => {
            return x.symbol === "XRPUSDT"
        })[0]
        bnb = x.filter(x => {
            return x.symbol === "BNBUSDT"
        })[0]
        $("#bnb").find(".value").html("$" + parseFloat(bnb.lastPrice).toFixed(2));
        $("#eth").find(".value").html("$" + parseFloat(eth.lastPrice).toFixed(2));
        $("#btc").find(".value").html("$" + parseFloat(btc.lastPrice).toFixed(2));
        $("#ltc").find(".value").html("$" + parseFloat(ltc.lastPrice).toFixed(2));
        $("#xrp").find(".value").html("$" + parseFloat(xrp.lastPrice).toFixed(2));
        $("#bnb").find(".percent").html(+parseFloat(bnb.priceChangePercent).toFixed(2) + "%");
        $("#eth").find(".percent").html(+parseFloat(eth.priceChangePercent).toFixed(2) + "%");
        $("#btc").find(".percent").html(+parseFloat(btc.priceChangePercent).toFixed(2) + "%");
        $("#ltc").find(".percent").html(+parseFloat(ltc.priceChangePercent).toFixed(2) + "%");
        $("#xrp").find(".percent").html(+parseFloat(xrp.priceChangePercent).toFixed(2) + "%");
    })
    $(".error").click(function() {
        $(this).hide();
    })

    function getQuote() {
        if (quoteTimeout !== null) {
            clearTimeout(quoteTimeout);
            quoteTimeout = null;
        }
        if ($("i.loading-quote").length > 0) {
            $("#withdrawAmount").val("");
            $("i.loading-quote").show();
        }
        quoteTimeout = setTimeout(function () {
            quoteTimeout = null;
            fetch("https://ctyvahls-dev.outsystemsenterprise.com/CointralOnline_Services/rest/Swap/GetQuote", {
                method: "POST",
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    DepositAsset: selectedDepositCurrency,
                    WithdrawAsset: selectedWithdrawCurrency,
                    DepositAmount: depositAmount
                })
            }).then(x => {
                if ($("i.loading-quote").length > 0) {
                    $("i.loading-quote").hide();
                }
                return x.json();
            }).then(x => {
                quoteDetail = x;
                $("#depositName").html(selectedDepositCurrency);
                $("#withdrawName").html(selectedWithdrawCurrency);
                $("#withdrawPrice").html(x.Price);
                $("#withdrawAmount").val(x.EstimatedWithdrawAmount);
                if (withdrawCurrency.MemoRegex) {
                    $("#memoAddress").show();
                }
                $("#withdrawAddress").attr("placeholder", `${selectedWithdrawCurrency} Alıcı Adresi`);
                if (top.location.pathname.includes("/order.html")) {
                    $("#loading").hide();
                    $(".area").show();
                }
            })
        }, 200);
    }
    fetch("https://ctyvahls-dev.outsystemsenterprise.com/CointralOnline_Services/rest/Swap/GetAllAssets").then(x => {
        return x.json();
    }).then(x => {
        list2.find(".list").empty();
        list1.find(".list").empty();
        allAssets = x;
        list2.find(".list").append('<div class="currency-group populercoin"><i class="fas fa-sort-amount-down"></i> Popüler coinler</div>');
        list1.find(".list").append('<div class="currency-group populercoin"><i class="fas fa-sort-amount-down"></i> Popüler coinler</div>');
        var sortAssets = allAssets.sort((a,b) => (a.Symbol > b.Symbol) ? 1 : ((b.Symbol > a.Symbol) ? -1 : 0));
        sortAssets.filter(fasset => fasset.Favorite === true).forEach(item => {
            if (item.DisplayName === "BTC")
                depositCurrency = item;
            if (item.DisplayName === "USDT (ERC20)")
                withdrawCurrency = item;
            if (item.DisplayName.includes("(")) {
                var p = item.DisplayName.substring(0, item.DisplayName.lastIndexOf("("));
                var k = item.DisplayName.substring(item.DisplayName.lastIndexOf("("), item.DisplayName.lastIndexOf(")") + 1);
                var html = `<button class="btn populercoin" data-symbol="${item.Symbol}"  data-short="${k}" data-displayname="${item.DisplayName}">
                    <img src="assets/images/icons/${item.Symbol}.svg" alt="">
                    <span class="currency-display-name">${item.Symbol}<sup>${k}</sup></span>
                    <span class="currency-name">${item.Name}</span>
                </button>`
            } else {
                var html = `<button class="btn populercoin" data-symbol="${item.Symbol}"  data-short="" data-displayname="${item.DisplayName}">
                    <img src="assets/images/icons/${item.Symbol}.svg" alt="">
                    <span class="currency-display-name">${item.Symbol}</span>
                    <span class="currency-name">${item.Name}</span>
                </button>`
            }
            list2.find(".list").append(html);
            list1.find(".list").append(html);
        });
        list2.find(".list").append('<div class="currency-group"><i class="fas fa-sort-alpha-down"></i> Tüm coinler</div>');
        list1.find(".list").append('<div class="currency-group"><i class="fas fa-sort-alpha-down"></i> Tüm coinler</div>');
        sortAssets.forEach(item => {
            if (item.DisplayName === "BTC")
                depositCurrency = item;
            if (item.DisplayName === "USDT (ERC20)")
                withdrawCurrency = item;
            if (item.DisplayName.includes("(")) {
                var p = item.DisplayName.substring(0, item.DisplayName.lastIndexOf("("));
                var k = item.DisplayName.substring(item.DisplayName.lastIndexOf("("), item.DisplayName.lastIndexOf(")") + 1);
                var html = `<button class="btn" data-symbol="${item.Symbol}"  data-short="${k}" data-displayname="${item.DisplayName}">
                    <img src="assets/images/icons/${item.Symbol}.svg" alt="">
                    <span class="currency-display-name">${item.Symbol}<sup>${k}</sup></span>
                    <span class="currency-name">${item.Name}</span>
                </button>`
            } else {
                var html = `<button class="btn" data-symbol="${item.Symbol}"  data-short="" data-displayname="${item.DisplayName}">
                    <img src="assets/images/icons/${item.Symbol}.svg" alt="">
                    <span class="currency-display-name">${item.Symbol}</span>
                    <span class="currency-name">${item.Name}</span>
                </button>`
            }
            list2.find(".list").append(html);
            list1.find(".list").append(html);
        });
    }).then(() => {
        getQuote()
    })
    $("#depositAmount").on("input", x => {
        depositAmount = x.target.value;
        if (x.target.value > 0) {
            getQuote();
        }
    })
    // list1.find("input").on("input", x=>{
    //     console.log("asdf");
    // })
    list1.find("input").on("input", x => {
        var filter = x.target.value.toLowerCase();
        count = 0;
        if (filter.trim().length > 0) {
            list1.find(".populercoin").hide();
            list1.find(".currency-group").addClass('mt-0');
        } else {
            list1.find(".populercoin").show();
            list1.find(".currency-group").removeClass('mt-0');
        }
        list1.find(".menu").find("button").not('.populercoin').each(function() {
            // If the list item does not contain the text phrase fade it out
            if ($(this).find("span").html().toLowerCase().search(filter) < 0) {
                $(this).hide(); // MY CHANGE
                // Show the list item if the phrase matches and increase the count by 1
            } else {
                $(this).show(); // MY CHANGE
                count++;
            }
        });
    })
    list2.find("input").on("input", x => {
        var filter = x.target.value.toLowerCase();
        count = 0;
        if (filter.trim().length > 0) {
            list2.find(".populercoin").hide();
            list2.find(".currency-group").addClass('mt-0');
        } else {
            list2.find(".populercoin").show();
            list2.find(".currency-group").removeClass('mt-0');
        }
        list2.find(".menu").find("button").not('.populercoin').each(function() {
            // If the list item does not contain the text phrase fade it out
            if ($(this).find("span").html().toLowerCase().search(filter) < 0) {
                $(this).hide(); // MY CHANGE
                // Show the list item if the phrase matches and increase the count by 1
            } else {
                $(this).show(); // MY CHANGE
                count++;
            }
        });
    })
    list3.find("input").on("input", x => {
        var filter = x.target.value.toLowerCase();
        count = 0;
        list3.find(".menu").find("button").each(function() {
            // If the list item does not contain the text phrase fade it out
            if ($(this).find("span").html().toLowerCase().search(filter) < 0) {
                $(this).hide(); // MY CHANGE
                // Show the list item if the phrase matches and increase the count by 1
            } else {
                $(this).show(); // MY CHANGE
                count++;
            }
        });
    })
    list4.find("input").on("input", x => {
        var filter = x.target.value.toLowerCase();
        count = 0;
        list4.find(".menu").find("button").each(function() {
            // If the list item does not contain the text phrase fade it out
            if ($(this).find("span").html().toLowerCase().search(filter) < 0) {
                $(this).hide(); // MY CHANGE
                // Show the list item if the phrase matches and increase the count by 1
            } else {
                $(this).show(); // MY CHANGE
                count++;
            }
        });
    })
    $(document).on("click", ".CoinList3 .menu button", function() {
        list3.find(".inner").find("span").attr("data-symbol", $(this).data("symbol"));
        list3.find(".inner").find("span").html($(this).data("symbol"));
        list3.find(".inner").find("img").attr("src", `assets/images/icons/${$(this).data("symbol")}.svg`)
        list3.find("a").html($(this).data("short"));
        $(".menu").hide();
    })
    $(document).on("click", ".CoinList4 .menu button", function() {
        list4.find(".inner").find("span").attr("data-symbol", $(this).data("symbol"));
        list4.find(".inner").find("span").html($(this).data("symbol"));
        list4.find(".inner").find("img").attr("src", `assets/images/currencies/${$(this).data("symbol")}.svg`)
        list4.find("a").html($(this).data("short"));
        $(".menu").hide();
    })
    $("#creditButton").click(x => {
        $('#creditButton').html('<i class="fas fa-spinner fa-pulse"></i>');
        var cryto = list3.find(".inner").find("span").data("symbol");
        var fiat = list4.find(".inner").find("span").data("symbol");
        var amount = $("#depositAmountCredit").val();
        selectedProcess = 0;
        localStorage.setItem("selectedProcess", selectedProcess)
        window.location.href = `order.html?crypto=${cryto}&fiat=${fiat}&amount=${amount}`;
    })
    $(document).on("click", ".CoinList4 .menu button", function() {
        list4.find(".inner").find("span").attr("data-symbol", $(this).data("symbol"));
        list4.find(".inner").find("span").html($(this).data("symbol"));
        $(".menu").hide();
    })
    $(document).on("click", ".CoinList1 .menu button", function() {
        $(".overlay").removeClass("show");
        if (selectedWithdrawCurrency === $(this).data("symbol")) {
            selectedWithdrawCurrency = "BTC";
            withdrawCurrency = allAssets.find(x => {
                return x.Symbol === "BTC";
            })
            list2.find(".inner").find("span").attr("data-symbol", selectedWithdrawCurrency);
            list2.find(".inner").find("span").html(selectedWithdrawCurrency);
            list2.find(".inner").find("img").attr("src", `assets/images/icons/${selectedWithdrawCurrency}.svg`)
            list2.find("a").html(withdrawCurrency.DisplayName.substring(withdrawCurrency.DisplayName.lastIndexOf("("), withdrawCurrency.DisplayName.lastIndexOf(")") + 1));
            Inputmask(withdrawCurrency.QtyLength !== 0 ? 'decimal' : 'integer', {
                autoUnmask: true,
                digits: withdrawCurrency.QtyLength,
                groupSeparator: ",",
                decimalSeparator: ".",
                autoGroup: true,
                rightAlign: false
            }).mask("#withdrawAmount")
        }
        if ($(this).data("symbol") === "BTC" && selectedWithdrawCurrency === "BTC") {
            selectedWithdrawCurrency = "USDT";
            withdrawCurrency = allAssets.find(x => {
                return x.Symbol === "USDT";
            })
            list2.find(".inner").find("span").attr("data-symbol", selectedWithdrawCurrency);
            list2.find(".inner").find("span").html(selectedWithdrawCurrency);
            list2.find(".inner").find("img").attr("src", `assets/images/icons/${selectedWithdrawCurrency}.svg`)
            list2.find("a").html(withdrawCurrency.DisplayName.substring(withdrawCurrency.DisplayName.lastIndexOf("("), withdrawCurrency.DisplayName.lastIndexOf(")") + 1));
            Inputmask(withdrawCurrency.QtyLength !== 0 ? 'decimal' : 'integer', {
                autoUnmask: true,
                digits: withdrawCurrency.QtyLength,
                groupSeparator: ",",
                decimalSeparator: ".",
                autoGroup: true,
                rightAlign: false
            }).mask("#withdrawAmount")
        }
        depositCurrency = allAssets.find(x => {
            return x.Symbol === $(this).data("symbol");
        })
        selectedDepositCurrency = depositCurrency.Symbol;
        getQuote();
        list1.find(".inner").find("span").attr("data-symbol", $(this).data("symbol"));
        list1.find("a").html($(this).data("short"));
        list1.find(".inner").find("span").html($(this).data("symbol"));
        list1.find(".inner").find("img").attr("src", `assets/images/icons/${selectedDepositCurrency}.svg`)
        Inputmask(withdrawCurrency.QtyLength !== 0 ? 'decimal' : 'integer', {
            autoUnmask: true,
            digits: withdrawCurrency.QtyLength,
            groupSeparator: ".",
            decimalSeparator: ".",
            autoGroup: true,
            rightAlign: false
        })
        $(".menu").hide();
    })
    $(document).on("click", ".CoinList2 .menu button", function() {
        $(".overlay").removeClass("show");
        console.log(selectedDepositCurrency === $(this).data("symbol"))
        if (selectedDepositCurrency === $(this).data("symbol")) {
            selectedDepositCurrency = "BTC";
            depositCurrency = allAssets.find(x => {
                return x.Symbol === "BTC";
            })
            list1.find(".inner").find("span").attr("data-symbol", selectedDepositCurrency);
            list1.find(".inner").find("span").html(selectedDepositCurrency);
            list1.find(".inner").find("img").attr("src", `assets/images/icons/${selectedDepositCurrency}.svg`)
            list1.find("a").html(depositCurrency.DisplayName.substring(depositCurrency.DisplayName.lastIndexOf("("), depositCurrency.DisplayName.lastIndexOf(")") + 1));
        }
        if ($(this).data("symbol") === "BTC" && selectedDepositCurrency === "BTC") {
            selectedDepositCurrency = "USDT";
            depositCurrency = allAssets.find(x => {
                return x.Symbol === "USDT";
            })
            list1.find(".inner").find("span").attr("data-symbol", selectedDepositCurrency);
            list1.find(".inner").find("span").html(selectedDepositCurrency);
            list1.find(".inner").find("img").attr("src", `assets/images/icons/${selectedDepositCurrency}.svg`)
            list1.find("a").html(depositCurrency.DisplayName.substring(depositCurrency.DisplayName.lastIndexOf("("), depositCurrency.DisplayName.lastIndexOf(")") + 1));
        }
        withdrawCurrency = allAssets.find(x => {
            return x.Symbol === $(this).data("symbol");
        })
        selectedWithdrawCurrency = withdrawCurrency.Symbol;
        getQuote();
        Inputmask(withdrawCurrency.QtyLength !== 0 ? 'decimal' : 'integer', {
            autoUnmask: true,
            digits: withdrawCurrency.QtyLength,
            groupSeparator: ",",
            decimalSeparator: ".",
            autoGroup: true,
            rightAlign: false
        }).mask("#withdrawAmount")
        list2.find("a").html($(this).data("short"));
        list2.find(".inner").find("span").attr("data-symbol", $(this).data("symbol"));
        list2.find(".inner").find("span").html($(this).data("symbol"));
        list2.find(".inner").find("img").attr("src", `assets/images/icons/${selectedWithdrawCurrency}.svg`)
        $(".menu").hide();
        $("#memoAddress").hide();
        if (withdrawCurrency.MemoRegex) {
            $("#memoAddress").show();
        }
    })
    $("#completeButton").click(x => {
        $('#completeButton').html('<i class="fas fa-spinner fa-pulse"></i>');
        $(".error").empty();
        selectedProcess = 1;
        if (depositAmount < quoteDetail.MinDeposit) {
            var html = `Yatrıılabilecek minimum ücreti <span style="color:white;">${quoteDetail.MinDeposit}</span>`
            $("#islemTabi").find(".error").show();
            $(".error").append(html);
            $('#completeButton').html($('#completeButton').data('original'));
        } else {
            localStorage.setItem("depositCurrency", JSON.stringify(depositCurrency))
            localStorage.setItem("withdrawCurrency", JSON.stringify(withdrawCurrency))
            localStorage.setItem("selectedProcess", selectedProcess)
            localStorage.setItem("depositAmount", depositAmount)
            window.location.href = "order.html";
        }
    })
    $(".swap").click(x => {
        var swaplist1Currency = list1.find('.menu button[data-displayname="' + withdrawCurrency.DisplayName + '"]'); // current: depositCurrency to: withdrawCurrency
        var swaplist2Currency = list2.find('.menu button[data-displayname="' + depositCurrency.DisplayName + '"]'); // current: withdrawCurrency to: depositCurrency
        if (swaplist1Currency.length > 0) {
        	swaplist1Currency.click();
        }
        if (swaplist2Currency.length > 0) {
        	swaplist2Currency.click();
        }
    })
    $(".swapOld").click(x => {
        var gecici = depositCurrency;
        depositCurrency = withdrawCurrency;
        withdrawCurrency = gecici;
        selectedDepositCurrency = depositCurrency.Symbol;
        selectedWithdrawCurrency = withdrawCurrency.Symbol;
        $("#withdrawAddress").attr("placeholder", `${selectedWithdrawCurrency} Alıcı Adresi`);
        list1.find(".inner").find("span").attr("data-symbol", selectedDepositCurrency);
        list1.find(".inner").find("span").html(depositCurrency.DisplayName);
        list2.find(".inner").find("span").attr("data-symbol", selectedWithdrawCurrency);
        list2.find(".inner").find("span").html(withdrawCurrency.DisplayName);
        getQuote();
    })
    // console.log(window.location.pathname);
    if (top.location.pathname.includes("/order.html")) {
        var trackcode;
        if (localStorage.getItem("depositAmount") && localStorage.getItem("selectedProcess") && localStorage.getItem("withdrawCurrency") && localStorage.getItem("depositCurrency")) {
            depositCurrency = JSON.parse(localStorage.getItem("depositCurrency"))
            withdrawCurrency = JSON.parse(localStorage.getItem("withdrawCurrency"))
            selectedProcess = localStorage.getItem("selectedProcess")
            depositAmount = localStorage.getItem("depositAmount");
            selectedDepositCurrency = depositCurrency.Symbol;
            selectedWithdrawCurrency = withdrawCurrency.Symbol;
            if (withdrawCurrency.MemoRegex) {
                $("#memoAddress").show();
            }
            if (selectedProcess === "2") {
                trackcode = localStorage.getItem("trackCode");
                if (trackcode) {
                    $(".trackCode").html(trackcode);
                    GetSwapStatus();
                }
            }
            if (depositCurrency.DisplayName.includes("(")) {
                var p = depositCurrency.DisplayName.substring(0, depositCurrency.DisplayName.lastIndexOf("("));
            } else {
                var p = depositCurrency.DisplayName
            }
            if (withdrawCurrency.DisplayName.includes("(")) {
                var p2 = withdrawCurrency.DisplayName.substring(0, withdrawCurrency.DisplayName.lastIndexOf("("));
            } else {
                var p2 = withdrawCurrency.DisplayName;
            }
            list2.find("a").html(withdrawCurrency.DisplayName.substring(withdrawCurrency.DisplayName.lastIndexOf("("), withdrawCurrency.DisplayName.lastIndexOf(")") + 1));
            list1.find("a").html(depositCurrency.DisplayName.substring(depositCurrency.DisplayName.lastIndexOf("("), depositCurrency.DisplayName.lastIndexOf(")") + 1));
            list2.find(".inner").find("span").attr("data-symbol", withdrawCurrency.Symbol);
            list2.find(".inner").find("span").html(p2);
            list1.find(".inner").find("span").attr("data-symbol", depositCurrency.Symbol);
            list1.find(".inner").find("span").html(p);
            $("#depositAmount").val(depositAmount);
        }
        if (selectedProcess === "0") {
            $("#homeTab").find("span").removeClass("active");
            $("#credit").addClass("active")
            $("#simplex").show();
            $("#swap").hide();
            $("#wallet").hide();
        }
        $("#credit").click(x => {
            $("#simplex").show();
            $("#swap").hide();
            $("#wallet").hide();
        })
        $("#trade").click(x => {
            $("#simplex").hide();
            $("#swap").show();
            $("#wallet").show();
        })

        function startTimer(duration, display) {
            var timer = duration,
                minutes, seconds;
            setInterval(function() {
                minutes = parseInt(timer / 60, 10);
                seconds = parseInt(timer % 60, 10);
                minutes = minutes < 10 ? "0" + minutes : minutes;
                seconds = seconds < 10 ? "0" + seconds : seconds;
                display.textContent = minutes + ":" + seconds;
                if (--timer < 0) {
                    location.reload(true);
                    timer = duration;
                }
            }, 1000);
        }
        var swapDetail;

        function proccess() {
            fetch(`https://ctyvahls-dev.outsystemsenterprise.com/CointralOnline_Services/rest/Swap/GetSwapStatus?TrackCode=${trackcode}`).then(x => {
                return x.json()
            }).then(x => {
                swapDetail = x;
                if (!timer && x.Status === "Waiting for deposit") {
                    let dateOne = new Date(swapDetail.CreatedOn);
                    let dateTwo = new Date();
                    let msDifference = dateTwo - dateOne;
                    let minutes = msDifference / 1000 / 60;
                    if (minutes <= 30) {
                        var fiveMinutes = 60 * 30 - (60 * minutes)
                        display = document.querySelector('.time');
                        startTimer(fiveMinutes, display);
                        timer = true;
                        $(".timeArea").show();
                    } else {
                        $(".timeArea").hide();
                    }
                }
                if (x.Status !== "Waiting for deposit") {
                    $(".timeArea").hide();
                }
                $("#step1").hide();
                $("#step2").show();
                $("#qrCode").empty();
                $("#qrCode").qrcode({
                    // render method: 'canvas', 'image' or 'div'
                    render: 'canvas',
                    // error correction level: 'L', 'M', 'Q' or 'H'
                    ecLevel: 'L',
                    // size in pixel
                    size: 150,
                    // code color or image element
                    fill: '#000',
                    // content
                    text: swapDetail.DepositAddress,
                });
                if (swapDetail.WithdrawAddressTag) {
                    $("#withdrawTag").show();
                    $("#getTag").html(swapDetail.WithdrawAddressTag);
                }
                if (swapDetail.DepositAddressTag) {
                    $("#tagCode").show();
                    $(".tag").show();
                    $(".tagQrArea").show();
                    $("#tagCode").empty();
                    $("#tagCode").qrcode({
                        // render method: 'canvas', 'image' or 'div'
                        render: 'canvas',
                        // error correction level: 'L', 'M', 'Q' or 'H'
                        ecLevel: 'L',
                        // size in pixel
                        size: 150,
                        // code color or image element
                        fill: '#000',
                        // content
                        text: swapDetail.DepositAddressTag,
                    });
                    $("#tagAddress").find("span").html(swapDetail.DepositAddressTag);
                }
                if (x.Status === "Waiting for deposit" || x.Status === "Deposited") {
                    var html = `${swapDetail.DepositAmountExpected} ${swapDetail.DepositAsset}`
                    $("#alinacakTutar").html(html);
                    $("#sendAddress").find("span").html(swapDetail.DepositAddress);
                    $("#step22").hide();
                    var html2 = `${swapDetail.WithdrawAmountEstimated} ${swapDetail.WithdrawAsset}`
                    $("#verilecekTutar").html(html2);
                    $("#getAddress").html(swapDetail.WithdrawalAddress);
                    $("#line2").addClass("active")
                    $("#mid").addClass("active")
                }
                if (x.Status === "Done") {
                    $("#stage2").addClass("active");
                    $("#step2").hide();
                    $("#step3").show();
                    $("#line2").addClass("active")
                    $("#mid").addClass("active")
                    $("#line3").addClass("active")
                    $("#final").addClass("active")
                    $("#line4").addClass("active")
                    clearInterval(interval);
                    var html = `${swapDetail.DepositAmount} ${swapDetail.DepositAsset}`
                    $("#step3").find(".coinPrice").html(html);
                    $("#step3").find("#coinAddress").html(swapDetail.DepositAddress);
                    html = `${swapDetail.WithdrawAmount} ${swapDetail.WithdrawAsset}`
                    $("#step3").find("#coinPrice2").html(html);
                    $("#step3").find("#coinAddress2").html(swapDetail.WithdrawalAddress);
                    if (swapDetail.DepositAddressTag) {
                        $("#step3").find(".tag").show();
                        $("#step3").find(".tag").find("#getTagDone1").html(swapDetail.DepositAddressTag)
                        $("#step3").find(".tag").show();
                        $("#step3").find(".tag").find("#getTagDone2").html(swapDetail.WithdrawAddressTag)
                    }
                }
                if (x.Status === "Cancelled") {
                    $("#stage2").addClass("active");
                    $("#step1").hide();
                    $("#step2").hide();
                    $("#step3").hide();
                    $("#step4").show();
                    $("#line2").addClass("active")
                    $("#mid").addClass("active")
                    $("#line3").addClass("active")
                    clearInterval(interval);
                    $("#final").addClass("active")
                    $("#line4").addClass("active")
                    var html = `${swapDetail.DepositAmountExpected} ${swapDetail.DepositAsset}`
                    $("#step4").find(".coinPrice").html(html);
                    $("#step4").find("#coinAddressStep4").html(swapDetail.DepositAddress);
                    if (swapDetail.DepositAddressTag) {
                        $(".tag").show();
                        $(".tag").find("#coinAddresstag").html(swapDetail.DepositAddressTag)
                    }
                }
                if (x.Status === "Exchanged") {
                    $("#stage2").addClass("active");
                    $("#step21").hide();
                    $("#line2").addClass("active")
                    $("#mid").addClass("active")
                    $("#line3").addClass("active")
                    $("#step22").show();
                    var html = `${swapDetail.WithdrawAmount} ${swapDetail.WithdrawAsset}`
                    var html2 = `${swapDetail.DepositAmount} ${swapDetail.DepositAsset}`
                    $("#step22").find("#price1").html(html2);
                    $("#step22").find("#address1").html(swapDetail.DepositAddress);
                    $("#step22").find("#price2").html(html);
                    $("#step22").find("#address2").html(swapDetail.WithdrawalAddress);
                }
                $("#loading").hide();
                $(".area").show();
            })
        }
        timer = false;

        function GetSwapStatus() {
            proccess()
            interval = setInterval(() => {
                proccess()
            }, 3000);
        }
        $(".sendAddress").find("button").click(x => {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($("#sendAddress").find("span").html()).select();
            document.execCommand("copy");
            $temp.remove();
        })
        $("#tagAddress").find("button").click(x => {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($("#tagAddress").find("span").html()).select();
            document.execCommand("copy");
            $temp.remove();
        })
        $("button.trackCopy").click(x => {
            var $temp = $("<input>");
            $("body").append($temp);
            $temp.val($("span.trackCode").html()).select();
            document.execCommand("copy");
            $temp.remove();
        })

        function NewSwap() {
            $('#startButton').html('<i class="fas fa-spinner fa-pulse"></i>');
            fetch(`https://ctyvahls-dev.outsystemsenterprise.com/CointralOnline_Services/rest/Swap/NewSwap?DepositAsset=${selectedDepositCurrency}&WithDrawAsset=${selectedWithdrawCurrency}&DepositAmountExpected=${depositAmount}&WithdrawAddress=${$("#withdrawAddress").val()}&WithdrawAddressTag=${$("#memoAddress").val()}&WithdrawAmountEstimated=${quoteDetail.EstimatedWithdrawAmount}`, {
                method: "POST",
                body: JSON.stringify({
                    DepositAsset: selectedDepositCurrency,
                    WithDrawAsset: selectedWithdrawCurrency,
                    DepositAmountExpected: depositAmount,
                    WithdrawAddress: $("#withdrawAddress").val(),
                    WithdrawAddressTag: $("#memoAddress").val(),
                    WithdrawAmountEstimated: quoteDetail.EstimatedWithdrawAmount
                }),
                headers: { 'Content-Type': 'application/json' }
            }).then(x => {
                return x.json();
            }).then(x => {
                $('#startButton').html($('#startButton').data('original'));
                trackcode = x.TrackCode;
                $(".trackCode").html(trackcode);
                GetSwapStatus();
            })
        }
        $("#withdrawAddress").attr("placeholder", `${selectedWithdrawCurrency} Alıcı Adresi`);
        $("#startButton").click(x => {
            console.log(withdrawCurrency);
            var check1, check2, check3 = true;
            if (depositAmount < quoteDetail.MinDeposit) {
                var html = `Yatıralabilecek minimum ücreti <span >${quoteDetail.MinDeposit}</span>`
                $("#lowPrice").show();
                $("#lowPrice").html(html);
            } else {
                $("#withdrawAddressError").hide();
                $("#privacyCheckError").hide();
                $("#withdrawAddress").removeClass("invalid-input");
                $("#memoAddress").removeClass("invalid-input");
                $("#memoAdressError").hide();
                var re = new RegExp(withdrawCurrency.AddressRegex);
                if (re.exec($("#withdrawAddress").val())) {
                    check1 = true;
                } else {
                    $("#withdrawAddressError").show();
                    $("#withdrawAddress").addClass("invalid-input");
                }
                if ($('#privacyCheck').is(':checked')) {
                    check2 = true;
                } else {
                    $("#privacyCheckError").show();
                }
                if (withdrawCurrency.MemoRegex) {
                    if ($("#memoAddress").val().match(withdrawCurrency.MemoRegex)) {
                        check3 = true;
                    } else {
                        $("#memoAdressError").show();
                        $("#memoAddress").addClass("invalid-input");
                        check3 = false;
                    }
                }
                if (check1 && check2 && check3) {
                    NewSwap();
                }
            }
        })
    }
});