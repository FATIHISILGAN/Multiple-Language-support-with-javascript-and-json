$(document).ready(function() {
   
    var arrLang={
    
        'tr':{
            'y1':'Cointral Hızlı Takas, kripto paralarınızı hızlı ve kolayca takas etmenizi sağlar.',
            'y2':'200’den fazla kripto para çiftini hızlıca takas etmek için hemen başla',
            'y3':'Visa ve Mastercard ile ödeme kolaylığı',
            'y4':'Kredi Kartı ile Satın Al',
            'y5':'Takas İşlemi',
            'y6':'Takip',
            'y7':'Yatırılacak Miktar',
            'y8':'Yatırılacak Miktar',
            'y9':'Alınacak Miktar',
            'y10':'Alınacak Miktar',
            'y11':'Takip Kodu',
            'y12':'İşlemi Tamamla',
            'y13':'24 saatlik değişim',
            'y18':'En İyi Piyasa Oranları',
            'y19':'Cointral Hızlı Takas ile piyasadaki en iyi oranlarla kripto paralarınızı hızlıca takas edebilirsiniz.',
            'y20':'Hızlı İşlemler',
            'y21':'Cointral Hızlı Takas sayesinde kripto paralarınızı en hızlı şekilde birbirleriyle takas edebilirsiniz.',
            'y22':'Kullanıcı Desteği',
            'y23':'Cointral, takas işlemlerinizle ilgili şeffaf ve geniş kapsamlı desteği ile ihtiyaçlarınıza çözüm odaklı yaklaşır.',
            'y24':'Şirket',
            'y25':'Hakkımızda',
            'y26':'Ortaklar',
            'y27':'Yasal Bilgiler',
            'y28':'Kullanım Koşulları',
            'y29':'Gizlilik Politikası',
            'y30':'Destek',
            'y31':'Hızlı Takas Nedir?',
            'y32':'Nasıl Hızlı Takas Yaparım?',
            'y33':'S.S.S',
            'y34':'İletişim',
            'y35':' Cointral, güvenli, kolay kullanımlı ve uygun fiyatlarla dijital para alım-satım ve takas hizmeti sunma amacıyla hem fiziksel hem de online şubelere sahip, henüz regüle edilmemiş dijital para sektöründe faaliyet gösteren, her yönüyle yasal bir kuruluştur.',
            'y36':"Türkiye'de ve BAE'de faaliyet gösteren şube ve hizmetlerimizi küresel olarak yaygınlaştırmaktayız. Fiziki şubelerimize ek olarak Cointral platformumuz, kullanıcıların kredi kartı, havale yöntemleriyle dijital para birimlerini satın almalarına veya mevcut dijital para birimleri için düşük ücretler ile takas imkanı sağlar. ",
            'y37':'Misyonumuz, müşterilere kolay, sorunsuz ve güvenli bir platformda kripto para piyasasına yatırım yapma fırsatı sunmaktır. Global partnerlerimiz sayesinde en uygun dijital para kurlarını kullanır, gizli veya makul olmayan bir ücret çıkarmaz.',
            'y38':' Cointral Hızlı Takas, 200’den fazla kripto para çiftini hızlıca takas etmenizi sağlar. Piyasadaki en uygun fiyatlarla kripto paralarınızı dakikalar içinde takas edebilirsiniz.',
            'y39':'Cointral Hızlı Takas, kripto paralarınızı hızlı ve kolay bir şekilde takas edebilmenizi sağlayan bir servistir.',
            'y40':' Bitcoin, Ethereum, Litecoin, Tether ve 200’den fazla kripto para çifti ile takas işlemlerinizi yapabilirsiniz. Cointral.com’da Tüm Piyasalar veya Desteklenen Para Birimleri bölümünde hızlı takas yapabileceğiniz kripto paraları görebilirsiniz.',
            'y41':'Cointral ile kripto paralarınızı takas edebilmek çok kolay.   Takas işlemleri için; Cointral.swap adresine girdikten sonra ana sayfanın sağ tarafında bulunan Kredi kartı ile Satın al ve Takas işlemi butonlarından Takas İşlemini seçmelisiniz.  ',
          
          
            'y42':'Takas edeceğiniz kripto para birimlerini ve miktarı belirledikten sonra “ İşlemi Tamamla    butonuna basarak işleminize devam edebilirsiniz. Daha sonra bilgilerinizi kontrol ettikten “   sonra alıcı adresi bölümüne cüzdan adresinizi eksiksiz bir şekilde yazmalısınız. ',
    
         
          
            'y43':'  Ödeme ekranına geldiğinizde ödemenizi QR Kod ile yapabildiğiniz gibi cüzdan adresi ile de gerçekleştirebilirsiniz. Ödemenizi gerçekleştirmenizin ardından takas işleminiz başarılı bir  şekilde gerçekleşecektir.',
            
            'y44':'Kredi Kartı ile Satın Al',
            'y45':'Takas İşlemi',
            'y46':'Tutarı Hesapla',
            'y47':'Yatırılacak Miktar',
            'y48':'Alınacak Miktar',
            'y49':'Cüzdan Adresi',
            'y50':'Alıcının Adresi',
            'y51':'Cüzdan Adresi Geçerli Değil',
            'y52':'MEMO adresi geçerli değil',
            'y53':'Kullanım Şartları, Gizlilik Politikası ve AML/KYC’yi kabul ediyorum.',
            'y54':'Kullanıcı Sözleşmesini kabul ediniz.',
            'y55':'Ödeme Yap',
            'y56':'Lütfen takas etmek istediğiniz tutarı gönderin',
            'y57':'Kalan Süre',
            'y58':'Göndereceğiniz Tutar',
            'y59':'Göndereceğiniz Adres',
            'y60':'TAG Adresi',
            'y61':'Takip Kodu',
            'y62':'Takip kodunuzu lütfen saklayınız!<br>Bu kod ile işleminizin durumunu kontrol edebilirsiniz.',
            'y63':'Alacağınız Yaklaşık Tutar',
            'y64':'Alacağınız Adres',
            'y65':'Gönderilecek Adres TAG',
            'y66':'İşlem Gerçekleştiriliyor',
            'y67':'İşlemin gerçekleşmesi sistemdeki yoğunluğa bağlı olarak ortalama 5-30 dakika arası sürebilir. Lütfen bekleyiniz',
            'y68':'Gönderdiğiniz Miktar',
            'y69':'Gönderdiğiniz Adres',
            'y70':'Alacağınız Miktar',
            'y71':'Dönüşümü Alacağınız Adres',
            'y72':'Ödeme Bekleniyor',
            'y73':'Cüzdanınıza Gönderiliyor',
            'y74':'Aldığınız Tutar',
            'y75':'Aldığınız Adres',
            'y76':'Aldığınız Adres TAG',
            'y77':'İşlem İptal Edildi',
            'y78':'Gönderilecek Tutar',
            'y79':'Gönderilecek Adres',
            'y80':'Sebep',
            'y81':'Belirtilen süre içinde yatırma gerçekleştirmediğiniz için işlem iptal edildi',
    
            'y82':'Sıkça Sorulan Sorular',
            'y83':'Cointral Hızlı Takas nedir?',
            'y84':'Cointral Hızlı Takas, kripto paralarınızı hızlı ve kolay bir şekilde takas edebilmenizi sağlayan bir servistir.',
            'y85':'Cointral Hızlı Takas hangi kripto paralarla işlem yapabilirim?',
            'y86':'Bitcoin, Ethereum, Litecoin, Tether ve 200’den fazla kripto para çifti ile takas işlemlerinizi yapabilirsiniz. Cointral.com’da Tüm Piyasalar veya Desteklenen Para Birimleri bölümünde hızlı takas yapabileceğiniz kripto paraları görebilirsiniz',
            'y87':'Cüzdan adresi nedir? Cüzdan adresi yazarken nelere dikkat etmeliyim?',
            'y88':'Cüzdan adresi, sayı ve harflerin rastgele yerleşiminden oluşur. Cüzdan adresiniz transfer işlemlerinizi gerçekleştirmenizi sağlar. Cüzdan adresinizi yazarken yanlışsız ve eksiksiz olmasına dikkat etmelisiniz. Aksi takdirde varlıklarınız kaybolabilir ve yapılan işlemin geri dönüşü olmadığından dijital varlıklarınız kurtarılamaz.',
            'y89':'Cointral Hızlı Takas’ta nasıl para yatırabilirim?',
            'y90':'Cointral Hızlı Takas’ta para yatırmak için cüzdan adresine transfer yapabilir veya QR Kodu okutarak hızlı bir şekilde işleminizi tamamlayabilirsiniz',
            'y91':'Cointral Hızlı Takas’ı kimler kullanabilir?',
            'y92':'Cointral Hızlı Takas’ı kredi kartı ile dijital varlık satın almak isteyen ve dijital varlıklar arasında hızlı takas yapmak isteyen her kullanıcı kullanabilir',
    
            'y93':'Simplex, dünya çapında kredi kartı ile ödeme işlemleri sağlayan bir fintech şirketidir. Simplex teknolojisi, tüccarların, pazar alanlarının ve dijital varlık platformlarının çevrimiçi ödemelerini, eksiksiz ve geri ödeme kapsamı ile işleme koymalarını sağlar.',
            'y94':'Simplex’in algoritması, yüzlerce veri noktasını kaldırarak her ödeme ve her kullanıcıya ait riski analiz eder. Akış içi doğrulama mekanizmaları sayesinde sahte kullanıcıları engeller ve daha fazla satıcının çevrimiçi ödemeleri kabul etmesine kolaylık sağlar. ',
            'y95':'Simplex çevrimiçi kredi kartı işlemlerinde lisanslı bir finans şirketidir. Simplex, dünya çapındaki satıcıların, kredi kartı ile yapılan ödemeler ve alımlar dahil olmak üzere çeşitli ödeme yöntemlerini kabul etmelerine olanak tanır.',
            'y96':'   Dijital varlık endüstrisinde aktif bir güç olan Simplex, ana kullanıcılar için satın alma sürecini basitleştirme gibi ihtiyaçlara kolaylık sağlar. En büyük kripto para platformları ile çalışan ve yılda milyarlarca dolarlık işlem sağlayan Simplex, dijital varlık endüstrisinde bir standart haline gelmiştir. 2014 yılından bu yana hizmet veren ve ilk başlarda dijital para ekosisteminde faaliyet gösteren Simplex, hizmet alanını genişleterek e-ticaret endüstrisi ve diğer dikey sektörlerde de faaliyet göstermeye başladı. Cointral olarak bizler de, Simplex’in kredi kartı ile ödeme tecrübesinden ve sağladığı güvenden faydalanabilmek amacıyla, Simplex ile iş birliği yaparak, müşterilerimize daha iyi hizmet verme gayesindeyiz. ',
            'y97':'Simplex ile edinilen ayrıcalıklar: ',
            'y98':' • Kredi kartı ile kripto para satın alımı yapmanızı sağlar. Üstelik en üstün güvenlik tercihleri ile bu işlemleri endişe duymadan son derece güvenli bir şekilde gerçekleştirebilirsiniz.',
            'y99':'• Kredi kartı ile kripto para alımı yaparken dolandırıcılık gibi sorunlara karşı sizi uzman ekibiyle koruyarak gönül rahatlığıyla alışveriş yapmanıza olanak tanır. ',
            'y100':'• Ters ibraz riskine karşı sizi korur ve bu tarz işlemlere olanak tanımaz. ',
            'y101':'• Dünyanın hemen her yerinden dijital varlık işlemlerinizi kolayca yapmanızı sağlar. ',
            'y102':' • Simplex’in sahtekarlık önleme konusunda uzmanlığı, geniş bankacılık ağı, geniş blokzinciri teknolojisi bilgisi, dijital varlık sektöründeki deneyimi ve kanıtlanmış itibarı ile siz değerli müşterilerimize güvenli, kolay ve hızlı kredi kartı ile dijital para alma deneyimi sunar. ',
            'y103':'Kredi kartı ile nasıl işlem yapılır?',
            'y104':'  Sağ tarafta bulunan bölümde yer alan Kredi Kartı ile Satın Al butonuna tıklayarak yatıracağınız miktarı belirleyip işlem yapacağınız coinleri belirleyerek işleminize başlayabilirsiniz. Daha sonra kripto para adresinizi girerek işleminize devam edebilirsiniz. ',
            'y105':'  Daha sonra Simplex üzerinden Kart bilgilerinizi, adres bilgilerinizi ve kişisel bilgilerinizi eksiksiz bir şekilde girerek işleminize devam edebilirsiniz.',
            'y106':' Kart, adres ve diğer bilgilerinizi başarılı bir şekilde doldurmanızın ardından e-posta adresinize gelen onay mailini onaylamanız ve telefon numaranıza gelen 4 haneli kodu ilgili bölüme yazarak onay işlemini tamamlamanız gerekmektedir. ',
            'y107':'    Onaylama işleminden sonra işleminize devam edebilirsiniz.',
            'y108':'  Bu adımda sizden pasaport, kimlik veya sürücü belgenizin fotoğrafını eklemeniz istenmektedir. Fotoğrafı yüklerken üç aşamaya özen göstermelisiniz. ',
            'y110':'Fotoğrafın 4 köşesi de gözükecek şekilde olmalı. ',
            'y111':'Yüklediğiniz fotoğraftaki yazılar okunabilir olmalı. ',
            'y112':'Fotoğrafta flaş kullanılmamalı.  ',
            'y113':'  Yukarıdaki adımlara uyacak şekilde fotoğrafınızı ekleyerek, isim/soyisim, doğum tarihi, cinsiyet, ülke, kimlik numaranız ve kimlik numaranızın geçerlilik tarihini eksiksiz bir şekilde doldurun. Ardından adres bilgilerinizi yazarak eklediğiniz dosyayı yükleyebilirsiniz.',
            'y114':'   Kimlik ve diğer bilgilerinizi eksiksiz bir şekilde doldurduktan sonra sizden kart numaranızın ilk dört ve son dört rakamlarının belli olduğu bir selfie yapmanız istenmektedir. Ad soyad ve tarih görünür olmalı. Fotoğraf uygun ışıkla çekilmeli, kart detayları görünür şekilde yüzünüzü açıkça göstermelisiniz. Daha sonra çektiğiniz fotoğrafı sisteme yükleyerek işleminizi tamamlayabilirsiniz.',
            'y115':'dil seçin'
    
    
    
    
    
    
    
          
    
    
    
          
            
           
    
    
    
    
    
    
    
    
    
    
            
    
           
    
         
    
    
    
          
        },
        'en':{
            'y1':'Cointral Quick Swap allows you to exchange your cryptocurrencies quickly and easily.',
            'y2':'Get started now to quickly trade over 200 cryptocurrency pairs',
            'y3':'Payment with Visa and Mastercard',
            'y4':'Buy with Credit Card',
            'y5':'Clearing Process',
            'y6':'Tracking',
            'y7':'Amount to be deposited',
            'y8':'Amount to be deposited',
            'y9':'Amount to be received',
            'y10':'Amount to be received',
            'y11':'Tracking Code',
            'y12':'Complete the process',
            'y13':'24 hour change',
            'y18':'Best Market Rates',
            'y19':'With Cointral Quick Swap, you can quickly trade your cryptocurrencies at the best rates on the market.',
            'y20':'Quick Transactions',
            'y21':'With Cointral Quick Swap, you can exchange your crypto coins with each other in the fastest way possible.',
            'y22':'User Support',
            'y23':'Cointral approaches your needs in a solution-oriented manner with its transparent and comprehensive support regarding your clearing transactions.',
            'y24':'Company',
            'y25':'About us',
            'y26':'Partners',
            'y27':'Legal Information',
            'y28':'Terms of Use',
            'y29':'Privacy Policy',
            'y30':'Support',
            'y31':'What is Quick Swap?',
            'y32':'How Do I Trade Fast?',
            'y33':'F.A.Q',
            'y34':'Contact',
            'y35':'Cointral is a legal entity in all aspects, operating in the unregulated digital money sector, with both physical and online branches to offer digital currency trading and clearing services at affordable prices.',
            'y36':"We yaygınlaştırmakt as our global operating in Turkey and the UAE branches and service. In addition to our physical branches, our Cointral platform allows users to purchase digital currencies by credit card, money order methods or to exchange for existing digital currencies at low fees.",
            'y37':'Our mission is to offer customers the opportunity to invest in the cryptocurrency market on an easy, smooth and secure platform. Thanks to our global partners, it uses the most appropriate digital currency rates, does not charge any hidden or unreasonable fees.',
            'y38':' Cointral Quick Swap allows you to swap over 200 cryptocurrency pairs quickly. You can exchange your cryptocurrencies within minutes at the best prices on the market.',
            'y39':'Cointral Quick Swap is a service that allows you to exchange your cryptocurrencies quickly and easily.',
            'y40':'You can trade with Bitcoin, Ethereum, Litecoin, Tether, and more than 200 cryptocurrency pairs. In Cointral.com, you can see cryptocurrencies that you can swap fast in the All Markets or Supported Currencies section.',
            'y41':'It is very easy to exchange your cryptocurrencies with Cointral. For clearing transactions; After entering the Cointral.swap address, you must select the Clearing Process from the Buy with credit card and Clearing transaction buttons on the right side of the main page. ',
          
          
            'y42':'After determining the crypto currencies and amount you will exchange, you can continue your transaction by clicking the "Complete Transaction button. Then, after checking your information, you should write your wallet address completely in the recipient address section. ',
    
         
          
            'y43':'  When you come to the payment screen, you can make your payment with QR Code as well as with your wallet address. After you make your payment, your clearing process will be completed successfully.',
    
    
            'y44':'Buy with Credit Card',
            'y45':'Clearing Process',
            'y46':'Calculate Amount',
            'y47':'Amount to be deposited',
            'y48':'Amount to be received',
            'y49':'Wallet Address',
            'y50':"Recipient's Address",
            'y51':'Wallet Address Is Not Valid',
            'y52':'MEMO address is not valid',
            'y53':'I accept the Terms of Use, Privacy Policy and AML / KYC.',
            'y54':'Accept the User Agreement.',
            'y55':'Pay',
            'y56':'Please submit the amount you want to trade',
            'y57':'Time Left',
            'y58':'Amount You Send',
            'y59':'Your Address',
            'y60':'TAG Adress',
            'y61':'Tracking Code',
            'y62':'Please keep your tracking code! <br> You can check the status of your transaction with this code.',
            'y63':'Approximate Amount You Will Receive',
            'y64':'Your Address',
            'y65':'Address to be sent TAG',
            'y66':'Processing Process',
            'y67':'The process may take an average of 5-30 minutes depending on the intensity of the system. Please wait',
            'y68':'Amount You Send',
            'y69':'Your Address',
            'y70':'The Amount You Will Receive',
            'y71':'The Address You Will Get the Transformation',
            'y72':'Waiting for Payment',
            'y73':'Sending to Your Wallet',
            'y74':'Amount Received',
            'y75':'Your Address',
            'y76':'Your Address TAG',
            'y77':'Transaction Canceled',
            'y78':'Amount to be Sent',
            'y79':'Address to be sent',
            'y80':'Reason',
            'y81':'The transaction was canceled because you did not make a deposit within the specified time',
    
            'y82':'Frequently Asked Questions',
            'y83':'What is Cointral Quick Swap?',
            'y84':'Cointral Quick Swap is a service that allows you to exchange your cryptocurrencies quickly and easily.',
            'y85':'Cointral Quick Swap which cryptocurrencies can I trade with?',
            'y86':'You can trade with Bitcoin, Ethereum, Litecoin, Tether, and more than 200 cryptocurrency pairs. On Cointral.com, you can see cryptocurrencies that you can swap fast in the All Markets or Supported Currencies section.',
            'y87':'What is the wallet address? What should I pay attention to when writing a wallet address?',
            'y88':'Wallet address consists of random placement of numbers and letters. Your wallet address allows you to perform your transfer transactions. When writing your wallet address, you should pay attention to being accurate and complete. Otherwise, your assets may be lost and your digital assets cannot be recovered since the transaction is irreversible.',
            'y89':'How can I deposit money in Cointral Quick Swap?',
            'y90':'To deposit money in Cointral Quick Clearing, you can transfer to your wallet address or complete your transaction quickly by scanning the QR Code.',
            'y91':'Who can use Cointral Quick Swap?',
            'y92':'Cointral Quick Swap can be used by any user who wants to buy digital assets with a credit card and want to quickly exchange between digital assets.',
            
          
            'y93':'Simplex is a fintech company providing credit card payment transactions worldwide. Simplex technology enables merchants, marketplaces and digital asset platforms to process their online payments with complete and repayment coverage.',
            'y94':"Simplex's algorithm removes hundreds of data points, analyzing the risk of each payment and each user. Thanks to in-stream verification mechanisms, it prevents fraudulent users and makes it easier for more sellers to accept online payments.",
            'y95':'Simplex is a licensed financial company for online credit card transactions. Simplex allows merchants around the world to accept a variety of payment methods, including credit card payments and purchases.',
            'y96':"As an active force in the digital asset industry, Simplex provides convenience to needs such as simplifying the purchasing process for mainstream users. Working with the largest cryptocurrency platforms and providing billions of dollars of transactions annually, Simplex has become a standard in the digital asset industry. Simplex, which has been serving since 2014 and initially operating in the digital money ecosystem, has expanded its service area and started to operate in the e-commerce industry and other vertical sectors. As Cointral, we aim to provide better service to our customers by cooperating with Simplex in order to benefit from Simplex's credit card payment experience and the trust it provides. ",
            'y97':'Privileges acquired with Simplex: ',
            'y98':' • Allows you to buy cryptocurrencies with credit cards. Moreover, with the highest security choices, you can perform these operations in an extremely secure way without worrying.',
            'y99':'• It allows you to shop with peace of mind by protecting you against problems such as fraud with its expert team while purchasing crypto money with credit card. ',
            'y100':'• It protects you against the risk of chargeback and does not allow such transactions.',
            'y101':'• Allows you to easily perform digital asset transactions from almost anywhere in the world. ',
            'y102':"• With Simplex's expertise in fraud prevention, extensive banking network, extensive blockchain technology knowledge, experience in the digital asset sector and proven reputation, it offers our valued customers the experience of receiving digital money with a safe, easy and fast credit card. ",
            'y103':'How to make transactions with credit cards?',
            'y104':'You can start your transaction by determining the amount you will deposit and the coins you will trade by clicking the Buy with Credit Card button on the right side. You can then continue your transaction by entering your cryptocurrency address.',
            'y105':'Then, you can continue your transaction by entering your card information, address information and personal information completely on Simplex.',
            'y106':' After successfully filling in your card, address and other information, you need to confirm the confirmation email sent to your e-mail address and complete the approval process by writing the 4-digit code sent to your phone number to the relevant section. ',
            'y107':'After the confirmation, you can continue your transaction.',
            'y108':"At this step, you will be asked to add a photo of your passport, ID or driver's license. When uploading the photo, you should pay attention to three stages.",
            'y110':'All 4 corners of the photo should be visible. ',
            'y111':'The text in the photo you uploaded must be legible. ',
            'y112':'Flash should not be used in photography.',
            'y113':'Fill in your name / surname, date of birth, gender, country, identity number and validity date of your identity number by adding your photo in accordance with the steps above. Then you can upload the file you added by typing your address information.',
            'y114':'After completing your identity and other information, you are asked to take a selfie with the first four and last four digits of your card number. Name and date should be visible. The photo should be taken with appropriate light, and the card details should be visible and show your face clearly. You can then upload your photo to the system and complete your process.',
            'y115':'choose language'
            
           
    
    
    
    
            
    
    
    
    
            
    
        },
    
        'es':{
    
          'y1':'Cointral Quick Swap le permite intercambiar sus criptomonedas de forma rápida y sencilla.',
          'y2':'Empiece ahora a operar rápidamente con más de 200 pares de criptomonedas',
          'y3':'Fácil de pagar con Visa y Mastercard',
          'y4':'Comprar con tarjeta de crédito',
          'y5':'Proceso de compensación',
          'y6':'Rastreo',
          'y7':'Monto a depositar',
          'y8':'Monto a depositar',
          'y9':'Monto a recibir',
          'y10':'Monto a recibir',
          'y11':'Codigo de localización',
          'y12':'Completa el proceso',
          'y13':'Cambio de 24 horas',
          'y18':'Mejores tarifas del mercado',
          'y19':'Con Cointral Quick Swap, puede operar rápidamente con sus criptomonedas a las mejores tarifas del mercado.',
          'y20':'Transacciones rápidas',
          'y21':'Con Cointral Quick Swap, puede intercambiar sus criptomonedas entre sí de la manera más rápida posible.',
          'y22':'Soporte al usuario',
          'y23':'Cointral se acerca a sus necesidades de una manera orientada a la solución con su apoyo transparente y completo con respecto a sus transacciones de compensación.',
          'y24':'Empresa',
          'y25':'sobre nosotros',
          'y26':'Socios',
          'y27':'Información legal',
          'y28':'Términos de Uso',
          'y29':'Política de privacidad',
          'y30':'Apoyo',
          'y31':'¿Qué es Quick Swap?',
          'y32':'¿Cómo opero rápido?',
          'y33':'Preguntas más frecuentes',
          'y34':'contacto',
          'y35':' Cointral es una entidad legal en todos los aspectos, que opera en el sector de dinero digital no regulado, con sucursales físicas y en línea con el fin de brindar servicios de compensación y negociación de divisas digitales a precios asequibles.',
          'y36':"Nosotros yaygınlaştırmakt como nuestra operación global en Turquía y las sucursales y servicio de los Emiratos Árabes Unidos. Además de nuestras sucursales físicas, nuestra plataforma Cointral permite a los usuarios comprar monedas digitales con tarjeta de crédito, métodos de giro postal o cambiar por monedas digitales existentes a tarifas bajas.",
          'y37':'Nuestra misión es ofrecer a los clientes la oportunidad de invertir en el mercado de las criptomonedas en una plataforma fácil, fluida y segura. Gracias a nuestros socios globales, utiliza las tasas de cambio digitales más apropiadas, no cobra tarifas ocultas o irrazonables.',
          'y38':'Cointral Quick Swap le permite intercambiar más de 200 pares de criptomonedas rápidamente. Puedes cambiar tus criptomonedas en minutos a los mejores precios del mercado.',
          'y39':'Cointral Quick Swap es un servicio que le permite intercambiar sus criptomonedas de forma rápida y sencilla.',
          'y40':'Puede comerciar con Bitcoin, Ethereum, Litecoin, Tether y más de 200 pares de criptomonedas. En Cointral.com, puede ver las criptomonedas que puede intercambiar rápidamente en la sección Todos los mercados o Monedas admitidas.',
          'y41':'Es muy fácil intercambiar sus criptomonedas con Cointral. Para compensar transacciones; Después de ingresar la dirección de Cointral.swap, debe seleccionar el Proceso de compensación en los botones Comprar con tarjeta de crédito y Transacción de compensación en el lado derecho de la página principal.  ',
          
          
          'y42':'Después de determinar las monedas criptográficas y la cantidad que intercambiará, puede continuar con su transacción haciendo clic en el botón "Completar transacción". Luego, después de verificar su información, debe escribir la dirección de su billetera en la sección de dirección del destinatario completamente.',
    
       
        
          'y43':'  Cuando llegue a la pantalla de pago, puede realizar su pago con el Código QR y con la dirección de su billetera. Después de realizar su pago, su proceso de compensación se completará con éxito.',
    
    
          'y44':'Comprar con tarjeta de crédito',
            'y45':'Proceso de compensación',
            'y46':'Calcular la cantidad',
            'y47':'Monto a depositar',
            'y48':'Monto a recibir',
            'y49':'Dirección de billetera',
            'y50':'Dirección del destinatario',
            'y51':'La dirección de la billetera no es válida',
            'y52':'La dirección MEMO no es válida',
            'y53':'Acepto los Términos de uso, la Política de privacidad y AML / KYC.',
            'y54':'Acepte el Acuerdo de usuario.',
            'y55':'Ödeme Yap',
            'y56':'Envíe la cantidad que desea negociar',
            'y57':'Tiempo restante',
            'y58':'Cantidad que envía',
            'y59':'Su dirección',
            'y60':'Dirección TAG',
            'y61':'Codigo de localización',
            'y62':'¡Conserve su código de seguimiento! <br> Puede comprobar el estado de su transacción con este código.',
            'y63':'Cantidad aproximada que recibirá',
            'y64':'Su dirección',
            'y65':'Dirección a enviar TAG',
            'y66':'Proceso de procesamiento',
            'y67':'Proceso de procesamiento',
            'y68':'Cantidad que envía',
            'y69':'Su dirección',
            'y70':'La cantidad que recibirá',
            'y71':'La dirección en la que obtendrá la transformación',
            'y72':'A la espera del pago',
            'y73':'Enviar a su billetera',
            'y74':'Cantidad recibida',
            'y75':'Su dirección',
            'y76':'Su dirección TAG',
            'y77':'Transacción cancelada',
            'y78':'Cantidad a enviar',
            'y79':'Dirección a enviar',
            'y80':'Razón',
            'y81':'La transacción se canceló porque no realizó un depósito dentro del tiempo especificado',
          
    
    
            'y82':'Preguntas frecuentes',
            'y83':'¿Qué es Cointral Quick Swap?',
            'y84':'Cointral Quick Swap es un servicio que le permite intercambiar sus criptomonedas de forma rápida y sencilla.',
            'y85':'Cointral Quick Swap ¿con qué criptomonedas puedo comerciar?',
            'y86':'Puede comerciar con Bitcoin, Ethereum, Litecoin, Tether y más de 200 pares de criptomonedas. En Cointral.com, puede ver las criptomonedas que puede intercambiar rápidamente en la sección Todos los mercados o Monedas admitidas.',
            'y87':'¿Cuál es la dirección de la billetera? ¿A qué debo prestar atención al escribir una dirección de billetera?',
            'y88':'La dirección de la billetera consiste en la colocación aleatoria de números y letras. La dirección de su billetera le permite realizar sus transacciones de transferencia. Al escribir la dirección de su billetera, debe prestar atención a ser precisa y completa. De lo contrario, sus activos pueden perderse y sus activos digitales no se pueden recuperar ya que la transacción es irreversible.',
            'y89':'¿Cómo puedo depositar dinero en Cointral Quick Swap?',
            'y90':'Para depositar dinero en Cointral Quick Clearing, puede transferirlo a la dirección de su billetera o completar su transacción rápidamente escaneando el código QR.',
            'y91':'¿Quién puede utilizar Cointral Quick Swap?',
            'y92':'Cointral Quick Swap puede ser utilizado por cualquier usuario que desee comprar activos digitales con una tarjeta de crédito y desee intercambiar activos digitales rápidamente.',
    
    
    
    
          
            'y93':'Simplex es una empresa de tecnología financiera que ofrece transacciones de pago con tarjeta de crédito en todo el mundo. La tecnología Simplex permite a los comerciantes, mercados y plataformas de activos digitales procesar pagos en línea con cobertura completa y de pago.',
            'y94':'El algoritmo de Simplex elimina cientos de puntos de datos, analizando el riesgo de cada pago y de cada usuario. Gracias a los mecanismos de verificación in-stream, evita usuarios fraudulentos y facilita que más vendedores acepten pagos en línea. ',
            'y95':'Simplex es una empresa financiera con licencia para transacciones con tarjeta de crédito en línea. Simplex permite a los comerciantes de todo el mundo aceptar una variedad de métodos de pago, incluidos pagos y compras con tarjeta de crédito.',
            'y96':'Como fuerza activa en la industria de activos digitales, Simplex brinda conveniencia a necesidades tales como simplificar el proceso de compra para los principales usuarios. Trabajando con las plataformas de criptomonedas más grandes y proporcionando miles de millones de dólares en transacciones anualmente, Simplex se ha convertido en un estándar en la industria de activos digitales. Simplex, que ha estado prestando servicios desde 2014 e inicialmente operando en el ecosistema de dinero digital, ha ampliado su área de servicio y comenzó a operar en la industria del comercio electrónico y otros sectores verticales. Como Cointral, nuestro objetivo es brindar un mejor servicio a nuestros clientes al cooperar con Simplex para beneficiarnos de la experiencia de pago con tarjeta de crédito de Simplex y la confianza que brinda.',
            'y97':'Privilegios adquiridos con Simplex: ',
            'y98':'• Le permite comprar criptomonedas con tarjetas de crédito. Además, con las opciones de seguridad más altas, puede realizar estas operaciones de una manera extremadamente segura sin preocuparse.',
            'y99':'• Te permite comprar con tranquilidad protegiéndote de problemas como el fraude con su equipo de expertos mientras compras criptomonedas con tarjeta de crédito.',
            'y100':'•Lo protege contra el riesgo de devolución de cargo y no permite tales transacciones. ',
            'y101':'• Le permite realizar fácilmente sus transacciones de activos digitales desde casi cualquier parte del mundo. ',
            'y102':' • Con la experiencia de Simplex en prevención de fraude, una extensa red bancaria, un amplio conocimiento de la tecnología blockchain, experiencia en el sector de activos digitales y reputación probada, ofrece a nuestros valiosos clientes la experiencia de recibir dinero digital con una tarjeta de crédito segura, fácil y rápida. ',
            'y103':'Cómo realizar transacciones con tarjetas de crédito',
            'y104':' Puede comenzar su transacción determinando la cantidad a depositar y las monedas que intercambiará haciendo clic en el botón Comprar con tarjeta de crédito en el lado derecho. Luego puede continuar su transacción ingresando su dirección de criptomoneda.. ',
            'y105':' Más tarde, puede continuar con su transacción ingresando la información de su tarjeta, dirección e información personal completamente en Simplex.',
            'y106':' Después de completar con éxito su tarjeta, dirección y otra información, debe confirmar el correo electrónico de confirmación enviado a su dirección de correo electrónico y completar el proceso de aprobación escribiendo el código de 4 dígitos enviado a su número de teléfono en la sección correspondiente. ',
            'y107':'Después de la confirmación, puede continuar con su transacción.',
            'y108':' En este paso, se le pedirá que adjunte una foto de su pasaporte, identificación o licencia de conducir. Al subir la foto, debes prestar atención a tres etapas.',
            'y110':'Las 4 esquinas de la foto deben estar visibles.',
            'y111':'El texto de la foto que subiste debe ser legible.',
            'y112':'El flash no debe usarse en fotografía.',
            'y113':'Complete su nombre / apellido, fecha de nacimiento, sexo, país, número de identidad y fecha de validez de su número de identidad agregando su foto de acuerdo con los pasos anteriores. Luego, puede cargar el archivo que agregó escribiendo la información de su dirección.',
            'y114':'Después de completar su identidad y otra información, se le pedirá que se tome una selfie con los primeros cuatro y los últimos cuatro dígitos de su número de tarjeta. El nombre, apellido y fecha deben ser visibles. La foto debe tomarse con la luz adecuada y los detalles de la tarjeta deben ser visibles, mostrando su rostro claramente. Luego puede cargar su foto en el sistema y completar su proceso.',
            'y115':'elige lengua'
    
            
           
    
    
        
          
         
    
          
    
    
    
       
          
    
      }
    
    };
    
    
    
        $('.dropdown-item').click(function() {
         
          if($(this).attr('id')=="en"){
               
    $(location).attr('href', 'en/index.html');
          }
          
        });
    
          var lang ='en';
    
          $('a,h5,p,h1,h2,span,li,button,h3,label').each(function(index,element) {
            $(this).text(arrLang[lang][$(this).attr('key')]);
          
        });
    });